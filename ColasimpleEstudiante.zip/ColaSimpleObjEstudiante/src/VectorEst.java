
public class VectorEst {
	protected int MAX = 50;
	//por la relacion de composicion se define el vector de objetos estudiante
	protected Estudiante[] v = new Estudiante[MAX]; 
}
