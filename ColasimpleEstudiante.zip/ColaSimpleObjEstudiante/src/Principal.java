
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("MARCELO ARUQUIPA");
		System.out.println("CI 123456");
		
		ColaSimpleEst A = new ColaSimpleEst();
		A.llenar(4);
		A.mostrar();
		System.out.println("nro de elementos: " + A.nroElem());
		System.out.println(A.esVacia());
		System.out.println(A.esLlena());
	}
}
