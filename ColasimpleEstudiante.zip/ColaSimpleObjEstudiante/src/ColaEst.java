
public class ColaEst extends VectorEst{
	protected int fr;
	protected int fi;
	
	public ColaEst() {
		this.fr = -1;
		this.fi = -1;
	}
}
